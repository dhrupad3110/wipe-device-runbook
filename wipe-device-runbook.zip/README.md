# Azure Runbook: Wipe Intune-Managed Device

This PowerShell script enables automation of a remote wipe on a Windows device managed via Microsoft Intune using Azure Automation.

## Features
- Connects to Microsoft Graph
- Authenticates via Managed Identity or Certificate
- Issues a Wipe command to a device based on deviceId

## Requirements
- Azure Automation Account
- Managed Identity with Intune permissions
- Microsoft.Graph PowerShell SDK

## Usage
1. Import this script into an Azure Automation Runbook.
2. Provide a deviceId as a parameter.
3. Monitor job output for success.

## License
MIT
