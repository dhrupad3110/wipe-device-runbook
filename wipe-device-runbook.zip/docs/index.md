# Automating Intune Device Wipe with Azure Runbook

This automation helps IT admins trigger a wipe command for Intune-managed devices directly from Azure Automation.

### Why use this?
- No need to log into the Intune portal.
- Scripted automation for security response or deprovisioning.

[View script on GitHub](../Wipe_device_Azure-Runbook.ps1)
